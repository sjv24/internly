// this file will only be run once to create the database and tables
// db_creation.js

const mysql = require('mysql');

const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "admin"
});

db.connect(function (err) {
    if (err) throw err;
    console.log("Connected!");

    // Create database if not exists
    const sql_database = "CREATE DATABASE IF NOT EXISTS INTERNLY";
    db.query(sql_database, function (err, result) {
        if (err) throw err;
        console.log("INTERNLY Database Created or already exists");

        // Use the database
        db.query("USE INTERNLY", function (err, result) {
            if (err) throw err;
            console.log("Using database INTERNLY");

            const tables = [
                `CREATE TABLE IF NOT EXISTS STUDENTS (
                    s_id INT PRIMARY KEY AUTO_INCREMENT,
                    s_name VARCHAR(50),
                    s_email VARCHAR(255),
                    s_password VARCHAR(50),
                    s_birthdate DATE,
                    s_uni VARCHAR(255),
                    s_joining_date DATE,
                    s_gender CHAR(1),
                    s_year_of_study INT,
                    s_website VARCHAR(700)
                )`,

                `CREATE TABLE IF NOT EXISTS COMPANIES (
                    c_id INT PRIMARY KEY AUTO_INCREMENT,
                    c_name VARCHAR(100),
                    c_contact_name VARCHAR(100),
                    c_email VARCHAR(255),
                    c_password VARCHAR(50),
                    c_location VARCHAR(255),
                    c_industry VARCHAR(100)
                )`,

                `CREATE TABLE IF NOT EXISTS INTERNSHIPS (
                    i_id INT PRIMARY KEY AUTO_INCREMENT,
                    i_title VARCHAR(100) NOT NULL,
                    i_description TEXT,
                    i_location VARCHAR(100),
                    i_type ENUM('On-site', 'Remote', 'Hybrid') DEFAULT 'On-site',
                    i_duration VARCHAR(50),
                    i_start_date DATE,
                    i_application_deadline DATE,
                    i_stipend VARCHAR(50),
                    i_skills VARCHAR(255),
                    i_openings INT DEFAULT 1,
                    c_id INT,
                    c_name VARCHAR(100),
                    FOREIGN KEY (c_id) REFERENCES COMPANIES(c_id) ON DELETE CASCADE
                )`,

                `CREATE TABLE IF NOT EXISTS APPLICATIONS (
                    app_id INT PRIMARY KEY AUTO_INCREMENT,
                    s_id INT,
                    i_id INT,
                    app_date DATE,
                    status VARCHAR(50) DEFAULT 'Pending',
                    FOREIGN KEY (s_id) REFERENCES STUDENTS(s_id) ON DELETE CASCADE,
                    FOREIGN KEY (i_id) REFERENCES INTERNSHIPS(i_id) ON DELETE CASCADE
                )`,
];

            tables.forEach((sql, index) => {
                db.query(sql, function (err, result) {
                    if (err) throw err;
                    console.log(`Table ${index + 1} created or already exists.`);
                });
            });
        });
    });
});

module.exports = db;