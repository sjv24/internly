document.addEventListener("DOMContentLoaded", () => {
  // Get internship ID from URL search params
  const urlParams = new URLSearchParams(window.location.search);
  const internshipId = urlParams.get("id");

  if (!internshipId) {
    document.getElementById("internship-details").innerHTML = "<p>Invalid internship ID.</p>";
    return;
  }

  // Fetch internship details from backend
  fetch(`/internship?id=${internshipId}`)
    .then(res => {
      if (!res.ok) throw new Error("Failed to fetch internship");
      return res.json();
    })
    .then(internship => {
      // Display internship detail/ms and apply button
      document.getElementById("internship-details").innerHTML = `
        <h2>${internship.i_title}</h2>
        <h3>Company: ${internship.c_name}</h3>
        <p><strong>Location:</strong> ${internship.i_location}</p>
        <p><strong>Type:</strong> ${internship.i_type}</p>
        <p><strong>Duration:</strong> ${internship.i_duration}</p>
        <p><strong>Openings:</strong> ${internship.i_openings}</p>
        <p><strong>Stipend:</strong> ${internship.i_stipend}</p>
        <p><strong>Skills Required:</strong> ${internship.i_skills}</p>
        <p>${internship.i_description.replace(/\r\n/g, "<br>")}</p>
        <button id="apply-btn">Apply Now</button>
        <p id="apply-message" style="color:green;"></p>
      `;

      // Add click handler to apply button
      document.getElementById("apply-btn").addEventListener("click", () => {
        applyForInternship(internshipId);
      });
    })
    .catch(err => {
      document.getElementById("internship-details").innerHTML = `<p>Error loading internship details.</p>`;
      console.error(err);
    });
});

// Function to send application POST request
function applyForInternship(internshipId) {
  fetch("/apply", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ i_id: internshipId })
  })
    .then(res => {
      if (!res.ok) throw new Error("Failed to apply");
      return res.text();
    })
    .then(msg => {
      const msgEl = document.getElementById("apply-message");
      msgEl.style.color = "green";
      msgEl.textContent = "Application submitted successfully!";
      document.getElementById("apply-btn").disabled = true;
    })
    .catch(err => {
      const msgEl = document.getElementById("apply-message");
      msgEl.style.color = "red";
      msgEl.textContent = "Failed to submit application.";
      console.error(err);
    });
}
